$(document).ready(function() {
    $(".menu-btn").click(function(){
        $(".navbar-nav").fadeToggle();
    })
});
