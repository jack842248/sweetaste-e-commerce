const gulp                 = require('gulp');
const sass                 = require('gulp-sass')(require('sass'));
const sourcemaps           = require('gulp-sourcemaps');
const postcss              = require('gulp-postcss');
const babel                = require('gulp-babel');
const plumber              = require('gulp-plumber');
const postcssFlexbugsFixes = require('postcss-flexbugs-fixes');
const postcssPresetEnv     = require('postcss-preset-env');
const autoprefixer         = require('autoprefixer');
const cssnano              = require('cssnano');
const concat               = require('gulp-concat');
const imagemin             = require('gulp-imagemin');
const newer                = require('gulp-newer');
const browserSync          = require('browser-sync').create();
const nunjucksRender       = require('gulp-nunjucks-render');
const del                  = require('del');

gulp.task('clean', function(){ 
    return del(['dist/**/*','!dist/images'],{
        gitignore: true, 
        force: true
    })
});

gulp.task('copy',function(){
    return gulp
        .src('src/font/*')
        .pipe(gulp.dest('dist/font'))
        .pipe(browserSync.stream());
})

gulp.task('layout',function(){
    return gulp
        .src('src/**/*.html')
        .pipe(nunjucksRender({
            path: ['src/templates']
        })) 
        .pipe(gulp.dest('dist'))
        .pipe(browserSync.stream());
});

gulp.task('sass',function(){
    return gulp
        .src('src/scss/**/*.*')
        .pipe(sourcemaps.init())
        .pipe(sass({
            outputStyle: 'compressed' 
        }).on('error',sass.logError))
        .pipe(
            postcss([ 
                postcssFlexbugsFixes(),
                postcssPresetEnv(),
                autoprefixer(), 
                cssnano({
                    preset: "advanced"
                })
            ])
        )
        .pipe(sourcemaps.write("./"))
        .pipe(gulp.dest('dist/css'))
        .pipe(browserSync.stream());
})

gulp.task('babel', function(){
    return gulp
        .src([
            'node_modules/jquery/dist/jquery.min.js', 
            'node_modules/bootstrap/dist/js/bootstrap.bundle.min.js', 
            'src/js/*.js'
        ])
        .pipe(plumber())
        .pipe(
            babel({  
                presets:['@babel/env'], 
                minified: true 
            })
        )
        .pipe(concat('all.js')) 
        .pipe(gulp.dest('dist/js')) 
        .pipe(browserSync.stream());
});

gulp.task('imagemin', function(){
    return gulp
        .src('src/images/**/*')
        .pipe(newer('dist/images'))
        .pipe(
            imagemin([
                imagemin.mozjpeg({
                    quality: 80, //壓縮品質
                }),
                imagemin.optipng({
                    optimizationLevel: 1 //優化級別
                }),
                imagemin.gifsicle({
                    interlaced : true //漸進式渲染
                }),
                imagemin.gifsicle()
            ])
        )
        .pipe(gulp.dest('dist/images'))
        .pipe(browserSync.stream());
});

gulp.task('watch', function(){
    browserSync.init({
        server: {
            baseDir: 'dist',
        },
        port: 3000,
        reloadDelay: 0,
        browser: 'google chrome',
        open: true
    });
    gulp.watch(['src/**/*.html','src/**/*.njk'], gulp.series('layout'));
    gulp.watch('src/scss/**/*.scss', gulp.series('sass'));
    gulp.watch('src/js/**/*.js', gulp.series('babel'));
});

gulp.task('default', gulp.series('clean','copy','layout','sass','babel','imagemin','watch'));
